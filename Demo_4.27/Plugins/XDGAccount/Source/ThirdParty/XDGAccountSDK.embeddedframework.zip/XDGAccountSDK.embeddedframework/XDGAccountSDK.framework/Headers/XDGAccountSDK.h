


#import <Foundation/Foundation.h>

#import <XDGAccountSDK/XDGAccount.h>


