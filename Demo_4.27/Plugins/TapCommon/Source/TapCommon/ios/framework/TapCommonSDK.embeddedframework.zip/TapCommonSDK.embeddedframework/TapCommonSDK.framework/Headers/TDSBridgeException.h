//
//  BridgeException.h
//  EngineBridge
//
//  Created by xe on 2020/10/9.
//  Copyright © 2020 xe. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TDSBridgeException : NSException
@end

