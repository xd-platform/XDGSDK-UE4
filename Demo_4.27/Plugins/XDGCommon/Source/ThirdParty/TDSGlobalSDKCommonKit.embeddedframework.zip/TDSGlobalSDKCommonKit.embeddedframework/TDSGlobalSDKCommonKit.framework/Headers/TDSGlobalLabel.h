//
//  TDSGlobalLabel.h
//  XdComPlatform
//
//  Created by JiangJiahao on 2020/5/14.
//  Copyright © 2020 X.D. Network Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^CopySuccessCallback)(void);

typedef NS_ENUM(NSInteger,TDSGlobalLabelVerticalAlignment) {
    TDSGlobalLabelVerticalAlignmentTop = 0,
    TDSGlobalLabelVerticalAlignmentCenter,
    TDSGlobalLabelVerticalAlignmentBottom,
};

@interface TDSGlobalLabel : UILabel
@property (nonatomic) UIEdgeInsets edgeInsets;
@property (nonatomic,assign) BOOL canCopy;
@property (nonatomic) CopySuccessCallback copyCallback;
@property (nonatomic,assign) TDSGlobalLabelVerticalAlignment verticalAlignment;
@end

NS_ASSUME_NONNULL_END
