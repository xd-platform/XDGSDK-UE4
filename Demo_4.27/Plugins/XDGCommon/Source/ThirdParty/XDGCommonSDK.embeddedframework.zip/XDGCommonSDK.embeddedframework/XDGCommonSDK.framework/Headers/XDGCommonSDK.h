

#import <Foundation/Foundation.h>

#import <XDGCommonSDK/XDGSDK.h>
#import <XDGCommonSDK/XDGSDKSettings.h>
#import <XDGCommonSDK/XDGGameDataManager.h>
#import <XDGCommonSDK/XDGEntryType.h>
#import <XDGCommonSDK/XDGGameBindEntry.h>
#import <XDGCommonSDK/XDGMainButton.h>
#import <XDGCommonSDK/XDGTrackerManager.h>
#import <XDGCommonSDK/XDGReportManager.h>
#import <XDGCommonSDK/XDGMessageManager.h>
#import <XDGCommonSDK/XDGShare.h>
#import <XDGCommonSDK/XDGUser.h>
#import <XDGCommonSDK/XDGUserDataManager.h>
#import <XDGCommonSDK/XDGAccessToken.h>
#import <XDGCommonSDK/XDGGlobalGame.h>

#define XDGSDK_VERSION @"6.0.1"
#define TDSGLOBALSDK_NAME @"XD-Intl-SDK"


